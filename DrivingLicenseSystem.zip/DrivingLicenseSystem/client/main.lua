local QBCore = exports['qb-core']:GetCoreObject()
local PlayerData = {}
local isInVehicle = false
local currentVehicle = nil
local licenseCheckActive = false
local hasLicense = false

-- Events
RegisterNetEvent('QBCore:Client:OnPlayerLoaded', function()
    PlayerData = QBCore.Functions.GetPlayerData()
    hasLicense = CheckPlayerLicense()
end)

RegisterNetEvent('QBCore:Client:OnJobUpdate', function(JobInfo)
    PlayerData.job = JobInfo
    hasLicense = CheckPlayerLicense()
end)

RegisterNetEvent('qb-drivinglicense:client:UpdateLicense', function(status)
    hasLicense = status
    if Config.Debug then
        print('[License System] License status updated:', status)
    end
end)

-- Functions
function CheckPlayerLicense()
    if not PlayerData or not PlayerData.metadata then return false end
    
    -- Check if player has exempt job
    if PlayerData.job and Config.ExemptJobs[PlayerData.job.name] then
        if Config.Debug then
            print('[License System] Player has exempt job:', PlayerData.job.name)
        end
        return true
    end
    
    -- Check license in metadata
    local licenseData = PlayerData.metadata.licences or {}
    local hasDriverLicense = licenseData[Config.LicenseType] or false
    
    if Config.Debug then
        print('[License System] License check result:', hasDriverLicense)
    end
    
    return hasDriverLicense
end

function ShowNotification(message, type)
    type = type or 'error'
    
    if Config.Notifications.type == 'qb-core' then
        QBCore.Functions.Notify(message, type, 5000)
    elseif Config.Notifications.type == 'ox_lib' then
        exports.ox_lib:notify({
            title = 'Driving License',
            description = message,
            type = type,
            position = Config.Notifications.position
        })
    else
        -- Custom notification system
        TriggerEvent('chat:addMessage', {
            color = type == 'error' and { 255, 0, 0 } or { 0, 255, 0 },
            multiline = true,
            args = { 'License System', message }
        })
    end
end

function IsVehicleClassRestricted(vehicle)
    local vehicleClass = GetVehicleClass(vehicle)
    return Config.RequiredVehicleClasses[vehicleClass] or false
end

function HandleUnlicensedDriver(vehicle)
    local playerPed = PlayerPedId()
    local vehicleCoords = GetEntityCoords(vehicle)
    local streetName = GetStreetNameFromHashKey(GetStreetNameAtCoord(vehicleCoords.x, vehicleCoords.y, vehicleCoords.z))
    
    -- Show access denied message
    ShowNotification(Lang:t('error.access_denied'), 'error')
    
    -- Alert police
    TriggerServerEvent('qb-drivinglicense:server:AlertPolice', {
        coords = vehicleCoords,
        street = streetName,
        vehicle = GetDisplayNameFromVehicleModel(GetEntityModel(vehicle))
    })
    
    -- Grace period before removing from vehicle
    SetTimeout(Config.GracePeriod, function()
        if IsPedInVehicle(playerPed, vehicle, false) then
            -- Turn off engine
            SetVehicleEngineOn(vehicle, false, true, true)
            
            -- Remove player from vehicle
            TaskLeaveVehicle(playerPed, vehicle, 0)
            
            ShowNotification(Lang:t('error.kicked_from_vehicle'), 'error')
            
            if Config.Debug then
                print('[License System] Player removed from vehicle due to no license')
            end
        end
    end)
end

-- Main Thread
CreateThread(function()
    while true do
        Wait(Config.CheckInterval)
        
        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        
        if vehicle ~= 0 then
            if not isInVehicle or currentVehicle ~= vehicle then
                isInVehicle = true
                currentVehicle = vehicle
                licenseCheckActive = false
                
                -- Check if this vehicle requires a license
                if IsVehicleClassRestricted(vehicle) then
                    -- Check if player is the driver
                    if GetPedInVehicleSeat(vehicle, -1) == playerPed then
                        if not licenseCheckActive then
                            licenseCheckActive = true
                            hasLicense = CheckPlayerLicense()
                            
                            if not hasLicense then
                                if Config.Debug then
                                    print('[License System] Unlicensed driver detected')
                                end
                                HandleUnlicensedDriver(vehicle)
                            else
                                if Config.Debug then
                                    print('[License System] Licensed driver verified')
                                end
                            end
                        end
                    end
                end
            end
        else
            if isInVehicle then
                isInVehicle = false
                currentVehicle = nil
                licenseCheckActive = false
            end
        end
    end
end)

-- Engine Control Thread
CreateThread(function()
    while true do
        Wait(500)
        
        if isInVehicle and currentVehicle then
            local playerPed = PlayerPedId()
            
            -- Check if player is driver and doesn't have license
            if GetPedInVehicleSeat(currentVehicle, -1) == playerPed then
                if IsVehicleClassRestricted(currentVehicle) and not hasLicense then
                    -- Disable engine
                    SetVehicleEngineOn(currentVehicle, false, true, true)
                    SetVehicleUndriveable(currentVehicle, true)
                end
            end
        end
    end
end)
