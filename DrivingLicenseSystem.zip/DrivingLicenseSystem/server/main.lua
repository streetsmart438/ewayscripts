local QBCore = exports['qb-core']:GetCoreObject()

-- Commands
QBCore.Commands.Add('givelicense', Lang:t('commands.give_license'), {{name = 'id', help = 'Player ID'}}, true, function(source, args)
    local src = source
    local playerId = tonumber(args[1])
    
    if not playerId then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.invalid_player'), 'error')
        return
    end
    
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.player_not_found'), 'error')
        return
    end
    
    -- Update player metadata
    local licenseData = Player.PlayerData.metadata.licences or {}
    licenseData[Config.LicenseType] = true
    Player.Functions.SetMetaData('licences', licenseData)
    
    -- Notify both admin and player
    TriggerClientEvent('QBCore:Notify', src, Lang:t('success.license_given', {player = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname}), 'success')
    TriggerClientEvent('QBCore:Notify', playerId, Lang:t('success.license_given', {player = 'You'}), 'success')
    TriggerClientEvent('qb-drivinglicense:client:UpdateLicense', playerId, true)
    
    if Config.Debug then
        print('[License System] License granted to player:', playerId)
    end
end, 'admin')

QBCore.Commands.Add('removelicense', Lang:t('commands.remove_license'), {{name = 'id', help = 'Player ID'}}, true, function(source, args)
    local src = source
    local playerId = tonumber(args[1])
    
    if not playerId then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.invalid_player'), 'error')
        return
    end
    
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.player_not_found'), 'error')
        return
    end
    
    -- Update player metadata
    local licenseData = Player.PlayerData.metadata.licences or {}
    licenseData[Config.LicenseType] = false
    Player.Functions.SetMetaData('licences', licenseData)
    
    -- Notify both admin and player
    TriggerClientEvent('QBCore:Notify', src, Lang:t('success.license_removed', {player = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname}), 'success')
    TriggerClientEvent('QBCore:Notify', playerId, Lang:t('success.license_removed', {player = 'Your'}), 'error')
    TriggerClientEvent('qb-drivinglicense:client:UpdateLicense', playerId, false)
    
    if Config.Debug then
        print('[License System] License removed from player:', playerId)
    end
end, 'admin')

QBCore.Commands.Add('checklicense', Lang:t('commands.check_license'), {{name = 'id', help = 'Player ID'}}, true, function(source, args)
    local src = source
    local playerId = tonumber(args[1])
    
    if not playerId then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.invalid_player'), 'error')
        return
    end
    
    local Player = QBCore.Functions.GetPlayer(playerId)
    if not Player then
        TriggerClientEvent('QBCore:Notify', src, Lang:t('error.player_not_found'), 'error')
        return
    end
    
    local licenseData = Player.PlayerData.metadata.licences or {}
    local hasLicense = licenseData[Config.LicenseType] or false
    local status = hasLicense and 'has' or 'does not have'
    
    TriggerClientEvent('QBCore:Notify', src, Lang:t('success.license_check', {
        player = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname,
        status = status
    }), 'primary')
end, 'admin')

-- Events
RegisterNetEvent('qb-drivinglicense:server:AlertPolice', function(data)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if not Player then return end
    
    if Config.PoliceAlert.enabled then
        local policeCount = 0
        local Players = QBCore.Functions.GetQBPlayers()
        
        -- Count online police
        for _, v in pairs(Players) do
            if v.PlayerData.job.type == 'leo' and v.PlayerData.job.onduty then
                policeCount = policeCount + 1
            end
        end
        
        if policeCount >= Config.PoliceAlert.minPolice then
            -- Send alert to all police
            for _, v in pairs(Players) do
                if v.PlayerData.job.type == 'leo' and v.PlayerData.job.onduty then
                    local alertData = {
                        title = Lang:t('info.police_alert'),
                        message = Lang:t('info.police_alert_desc', {location = data.street}),
                        coords = data.coords,
                        sprite = 225,
                        color = 1,
                        scale = 1.0,
                        time = Config.PoliceAlert.alertDuration,
                        sound = true
                    }
                    
                    TriggerClientEvent('qb-policealerts:client:AddPoliceAlert', v.PlayerData.source, alertData)
                end
            end
            
            if Config.Debug then
                print('[License System] Police alert sent for unlicensed driver at:', data.street)
            end
        else
            -- Notify player that no police are available
            TriggerClientEvent('QBCore:Notify', src, Lang:t('info.no_police_online'), 'primary')
        end
    end
end)

-- Player loading event
RegisterNetEvent('QBCore:Server:PlayerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player then
        local licenseData = Player.PlayerData.metadata.licences or {}
        local hasLicense = licenseData[Config.LicenseType] or false
        
        TriggerClientEvent('qb-drivinglicense:client:UpdateLicense', src, hasLicense)
        
        if Config.Debug then
            print('[License System] Player loaded with license status:', hasLicense)
        end
    end
end)

-- Initialize default license data for new players
AddEventHandler('QBCore:Server:PlayerLoaded', function()
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    
    if Player then
        if not Player.PlayerData.metadata.licences then
            Player.Functions.SetMetaData('licences', {})
        end
    end
end)

if Config.Debug then
    print('[License System] Server script loaded successfully')
end
