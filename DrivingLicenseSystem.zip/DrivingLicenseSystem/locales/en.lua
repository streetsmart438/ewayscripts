local Translations = {
    error = {
        no_license = 'You do not have a valid driving license!',
        access_denied = 'Access Denied - No Driving License',
        kicked_from_vehicle = 'You have been removed from the vehicle due to no driving license',
        invalid_player = 'Invalid player ID',
        player_not_found = 'Player not found'
    },
    success = {
        license_given = 'Driving license granted to %{player}',
        license_removed = 'Driving license removed from %{player}',
        license_check = 'Player %{player} %{status} a driving license'
    },
    info = {
        police_alert = 'Unlicensed Driver Alert',
        police_alert_desc = 'Player without driving license attempting to drive at %{location}',
        checking_license = 'Checking driving license...',
        license_valid = 'Driving license verified',
        no_police_online = 'No police units available to respond'
    },
    commands = {
        give_license = 'Give driving license to player',
        remove_license = 'Remove driving license from player',
        check_license = 'Check player driving license status'
    }
}

Lang = Locale:new({
    phrases = Translations,
    warnOnMissing = true
})
